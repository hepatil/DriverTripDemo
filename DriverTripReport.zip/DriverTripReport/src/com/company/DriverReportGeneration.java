package com.company;

import com.company.dto.DriverDTO;
import com.company.dto.TripDTO;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.*;
import java.util.*;

/**
 * Author:Hemendra Date: 8/8/2020
 * CLass to generate Driver Trip Report
 * Version- v1
  */

public class DriverReportGeneration
{
    private final static Logger LOGGER =Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

    public static void main(String[] args) {
        try {

            LOGGER.log(Level.INFO,"DriverTripReport generation process started");
            Map<String, DriverDTO>driverMap = readFile();
            generateReport(driverMap);
            LOGGER.log(Level.INFO,"DriverTripReport is generated and stored in the Output file");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * Method to read Driver input informatipnm
     * @return Map driverMap
     * */
    private static Map<String, DriverDTO> readFile() {
        LOGGER.log(Level.INFO,"Start Reading File - method readFile");
        Path path = Paths.get("c://dev//Input.txt");
        Map<String, DriverDTO> driverMap = new HashMap<>();
        try {
            Stream<String> stream = Files.lines(path);
            stream.forEach( line ->
                    {
                        if(line.startsWith("Driver"))
                        {
                            DriverDTO driverDTO = new DriverDTO();
                            String[] driverLine = line.split("\\s+");
                            if(driverLine.length>1)
                            {
                                LOGGER.log(Level.INFO,"Setting Driver details for:"+driverLine[1]);
                                driverDTO.setDriver(driverLine[1]);
                                List<TripDTO> trips = new ArrayList<>();
                                driverDTO.setTrips(trips);
                                driverMap.put(driverDTO.getDriver(),driverDTO);
                            }
                        }
                        if(line.startsWith("Trip"))
                        {
                            String[] tripLine = line.split("\\s+");
                            if(tripLine.length>4)
                            {
                                LOGGER.log(Level.INFO,"Setting Trip details for:"+tripLine[1]);
                                DriverDTO driverDTO;
                                driverDTO = driverMap.get(tripLine[1]);
                                TripDTO trip = new TripDTO();
                                trip.setStartTime(tripLine[2]);
                                trip.setEndTime(tripLine[3]);
                                trip.setMiles( Double.parseDouble(tripLine[4]));
                                List<TripDTO> existingTrip = driverDTO.getTrips();
                                existingTrip.add(trip);
                            }
                        }
                    }
            );

        }
        catch (IOException e) {
            LOGGER.log(Level.INFO,"Error reading file");
            e.printStackTrace();
        }
        LOGGER.log(Level.INFO,"End of Reading File - method readFile");
        return driverMap;
    }
    /**
     * Generate the report for driver trip and call write into file.
     * @param driverMap which ha
     */
    private static void generateReport(Map<String, DriverDTO> driverMap)
    {
        LOGGER.log(Level.INFO,"Start generating report - method generateReport");
        List<DriverDTO> driversReports = new ArrayList<>();
        driverMap.forEach((id, driverDTO) -> {
            List<TripDTO> trips = driverDTO.getTrips();
            if(!trips.isEmpty())
            {
                double sumMiles=trips.stream().filter(t -> t!=null).mapToDouble(TripDTO::getMiles).sum();
                double hrs= trips.stream().filter(t -> t!=null).mapToDouble(TripDTO::getDateDiff).sum();
                String output = id+": "+Math.round(sumMiles) + " miles @ "+ Math.round(sumMiles /(hrs/3600000)) +" mph";
                DriverDTO driversReport = new DriverDTO();
                driversReport.setDriver(id);
                driversReport.setTotalMiles(Math.round(sumMiles));
                driversReport.setMph(Math.round(sumMiles /(hrs/3600000)));
                driversReports.add(driversReport);
            }
            else
            {
                DriverDTO driversReport = new DriverDTO();
                driversReport.setDriver(id);
                driversReport.setTotalMiles(0);
                driversReports.add(driversReport);
            }
        });
        generateResponseFile(driversReports);
        LOGGER.log(Level.INFO,"End generating report - method generateReport");
    }
    /**
 * Write driver report into file.
 * @param driverReports List
 */
    static void generateResponseFile(List<DriverDTO> driverReports)
    {
        LOGGER.log(Level.INFO,"Start generating report File- method generateResponseFile");

        try {
            driverReports.sort((o1, o2) -> Double.compare(o2.getTotalMiles(), o1.getTotalMiles()));
            Path path = Paths.get("c://dev//Output.txt");
            StringBuilder response= new StringBuilder();
            driverReports.forEach( driverReport ->
                    {
                       if((driverReport.getMph() >= 5 && driverReport.getMph()<= 100)|| driverReport.getTotalMiles() ==0)  {
                           response.append(driverReport);
                           response.append(System.getProperty("line.separator"));
                       }
                    }
            );
            LOGGER.log(Level.INFO,"End generating report - method generateReport");
            try (BufferedWriter writer = Files.newBufferedWriter(path))
            {
                writer.write(response.toString());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        LOGGER.log(Level.INFO,"End generating report File - method generateResponseFile");
    }

}



