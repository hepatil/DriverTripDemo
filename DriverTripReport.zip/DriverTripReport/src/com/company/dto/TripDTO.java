package com.company.dto;

import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * Author:Hemendra Date: 8/8/2020
 * DTO Class for Trip
 */
public class TripDTO
{
    private String startTime;
    private String endTime;
    private double miles;

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public String getsetStartTime() {
        return this.startTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public String getEndTime() {
        return this.endTime;
    }
    public void setMiles(double miles) {
        this.miles = miles;
    }
    public double getMiles() {
        return this.miles;
    }
    public double getDateDiff() {
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        double tripHrs=0.0;
        try
        {
            Date date1 = format.parse(startTime);
            Date date2 = format.parse(endTime);
            tripHrs =  (date2.getTime() - date1.getTime());
            //System.out.println(tripHrs/3600000);
        }
        catch(Exception e)
        {
        }
        return tripHrs;
    }
}