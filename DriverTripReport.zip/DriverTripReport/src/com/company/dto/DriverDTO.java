package com.company.dto;
import java.util.List;
/**
 * Author:Hemendra Date: 8/8/2020
 * DTO Class for Driver
  */

public class DriverDTO
{
    private String driver;
    private double totalMiles;
    private double mph;

    private List<TripDTO> trips;
    public String getDriver() {
        return this.driver;
    }
    public void setDriver(String driver) {
        this.driver = driver;
    }
    public List<TripDTO> getTrips() {
        return this.trips;
    }
    public void setTrips(List<TripDTO> trips) {
        this.trips = trips;
    }
    public double getTotalMiles() {
        return this.totalMiles;
    }
    public void setTotalMiles(double totalMiles) {
        this.totalMiles = totalMiles;
    }
    public double getMph() {
        return this.mph;
    }
    public void setMph(double mph) {
        this.mph = mph;
    }

    public String toString() {
        if(Math.round(totalMiles)>0) {
            return driver + ": " + Math.round(totalMiles) + " miles @ " + Math.round(mph) + " mph";
        }
        else
        {
            return driver+": "+Math.round(totalMiles) + " miles";
        }
    }

}